#include <stdio.h>
#include <stdlib.h>
#include <time.h>

const unsigned long int num_vertex = 4039;
const unsigned long int num_edges = 88234;

struct Node;

struct DSS
{
    struct DSS *next;
    struct DSS *prev;
    struct Node *head;
    struct Node *tail;
    unsigned long int len;
};

struct Node
{
    struct DSS *root;
    unsigned long int data;
    struct Node *next;
};

struct Edge
{
    unsigned long int vert1;
    unsigned long int vert2;
    unsigned int weight;
};

void make_set(unsigned long int x, struct DSS *start)
{
    struct DSS *temp = start->next;
    struct DSS *new_DSS = (struct DSS *)malloc(sizeof(struct DSS));
    new_DSS->len = 1;
    new_DSS->next = temp;
    start->next = new_DSS;
    new_DSS->prev = start;

    if (temp)
        temp->prev = new_DSS;
    new_DSS->head = (struct Node *)malloc(sizeof(struct Node));
    new_DSS->tail = new_DSS->head;
    new_DSS->head->data = x;
    new_DSS->head->root = new_DSS;
    new_DSS->head->next = NULL;
}

struct DSS *find_set(unsigned long int val, struct DSS *start)
{
    struct DSS *DSS_iter = start->next;
    while (DSS_iter)
    {
        struct Node *node_iter = DSS_iter->head;
        while (node_iter)
        {
            if (node_iter->data == val)
                return node_iter->root;
            node_iter = node_iter->next;
        }
        DSS_iter = DSS_iter->next;
    }
    return NULL;
}

void link(struct DSS *x, struct DSS *y)
{
    if (x != y)
    {
        struct DSS *max, *min;
        if (x->len > y->len)
        {
            max = x;
            min = y;
        }
        else
        {
            max = y;
            min = x;
        }

        max->len += min->len;

        struct Node *change_pt = min->head;
        max->tail->next = min->head;
        max->tail = min->tail;
        while (change_pt)
        {
            change_pt->root = max;
            change_pt = change_pt->next;
        }

        if (min->prev)
            min->prev->next = min->next;

        if (min->next)
            min->next->prev = min->prev;

        free(min);
    }
}

void sort(struct Edge arr[], unsigned long int size)
{
    for (unsigned long int i = size - 1; i > 0; i--)
    {
        for (unsigned long int j = 0; j < i; j++)
        {
            if (arr[j].weight > arr[j + 1].weight)
            {
                struct Edge temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
        printf("%f %% done\r", 100 - ((float)i / (size - 1) * 100));
    }
}

void Union(struct Edge temp, struct DSS *start)
{
    if (temp.vert1 != temp.vert2)
        link(find_set(temp.vert1, start), find_set(temp.vert2, start));
}

unsigned long int mst_Kruskal(struct DSS *start, struct Edge wt[], int size)
{
    struct Edge *mst = (struct Edge *)malloc(size * sizeof(struct Edge));
    unsigned long int top = 0;
    for (int i = 0; i < size; i++)
    {
        if (find_set(wt[i].vert1, start) != find_set(wt[i].vert2, start))
        {
            mst[top++] = wt[i];
            Union(wt[i], start);
        }
    }
    unsigned long int sum = 0;
    for (int i = 0; i <= top; i++)
        sum += mst[i].weight;
    free(mst);
    return sum;
}

int main()
{

    struct Edge temp;

    struct DSS *start = (struct DSS *)malloc(sizeof(struct DSS));
    start->head = NULL;
    start->tail = NULL;
    start->len = 0;
    start->next = NULL;
    start->prev = NULL;

    FILE *fp = fopen("facebook_combined.txt", "r");

    for (unsigned long int i = 0; i < num_vertex; i++)
        make_set(i, start);

    unsigned long int *vert_wt = (unsigned long int *)malloc(num_vertex * sizeof(unsigned long int));
    struct Edge *wt = (struct Edge *)malloc(num_edges * sizeof(struct Edge));

    for (unsigned long int i = 0; i < num_edges; i++)
    {
        fscanf(fp, "%lu %lu", &temp.vert1, &temp.vert2);
        vert_wt[temp.vert1]++;
        vert_wt[temp.vert2]++;
        wt[i].vert1 = temp.vert1;
        wt[i].vert2 = temp.vert2;
    }

    for (int i = 0; i < num_edges; i++)
    {
        long int temp_wt = vert_wt[wt[i].vert1] - vert_wt[wt[i].vert2];
        if (temp_wt < 0)
            temp_wt *= -1;
        wt[i].weight = temp_wt;
    }

    free(vert_wt);

    sort(wt, num_edges);

    unsigned long int sum = mst_Kruskal(start, wt, num_edges);

    printf("\n sum is: %lu.\n", sum);

    fclose(fp);
}
