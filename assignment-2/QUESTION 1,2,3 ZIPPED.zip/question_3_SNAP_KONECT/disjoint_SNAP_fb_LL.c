#include <stdio.h>
#include <stdlib.h>
#include <time.h>

const unsigned long int num_vertex = 4039; // since their are total 4039 vertex in the data
const unsigned long int num_edges = 88234; // since their are total 88234 edges in the data

//struct Node;

struct DSS
{
    struct DSS *next;
    struct DSS *prev;
    struct Node *head;
    struct Node *tail;
    unsigned long int len;
};

struct Node
{
    struct DSS *root;
    unsigned long int data;
    struct Node *next;
};

struct Edge
{
    unsigned long int vert1;
    unsigned long int vert2;
};

void make_set(unsigned long int x, struct DSS *start)
{
    struct DSS *temp = start->next;
    struct DSS *new_DSS = (struct DSS *)malloc(sizeof(struct DSS));
    new_DSS->len = 1;
    new_DSS->next = temp;
    start->next = new_DSS;
    new_DSS->prev = start;

    if (temp)
        temp->prev = new_DSS;
    new_DSS->head = (struct Node *)malloc(sizeof(struct Node));
    new_DSS->tail = new_DSS->head;
    new_DSS->head->data = x;
    new_DSS->head->root = new_DSS;
    new_DSS->head->next = NULL;
}

struct DSS *find_set(unsigned long int val, struct DSS *start)
{
    struct DSS *DSS_iter = start->next;
    while (DSS_iter)
    {
        struct Node *node_iter = DSS_iter->head;
        while (node_iter)
        {
            if (node_iter->data == val)
                return node_iter->root;
            node_iter = node_iter->next;
        }
        DSS_iter = DSS_iter->next;
    }
    return NULL;
}

void link(struct DSS *x, struct DSS *y)
{
    if (x != y)
    {
        struct DSS *max, *min;
        if (x->len > y->len)
        {
            max = x;
            min = y;
        }
        else
        {
            max = y;
            min = x;
        }

        max->len += min->len;

        struct Node *change_pt = min->head;
        max->tail->next = min->head;
        max->tail = min->tail;
        while (change_pt)
        {
            change_pt->root = max;
            change_pt = change_pt->next;
        }

        if (min->prev)
            min->prev->next = min->next;

        if (min->next)
            min->next->prev = min->prev;

        free(min);
    }
}

void Union(struct Edge temp, struct DSS *start)
{
    if (temp.vert1 != temp.vert2)
        link(find_set(temp.vert1, start), find_set(temp.vert2, start));
}

int main()
{

    struct Edge temp;

    struct DSS *start = (struct DSS *)malloc(sizeof(struct DSS));
    start->head = NULL;
    start->tail = NULL;
    start->len = 0;
    start->next = NULL;
    start->prev = NULL;

    // char filepath[] = "facebook_combined.txt";
    // FILE *fp = fopen(filepath, "r");  // this produce the same result as in the next line ...

    FILE *fp = fopen("facebook_combined.txt", "r");

    for (unsigned long int i = 0; i < 4039; i++)
        make_set(i, start);

    for (unsigned long int i = 0; i < 88234; i++)
    {
        fscanf(fp, "%lu %lu", &temp.vert1, &temp.vert2);
        Union(temp, start);

        printf("%f %% done\r", (float)i / (num_edges - 1) * 100);
    }
}
