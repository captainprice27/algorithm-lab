#include <bits/stdc++.h>
#include <fstream>

using namespace std;

struct Point {
    int x, y;
};

double dist(const Point &p1, const Point &p2) {
    return sqrt(pow(p1.x - p2.x, 2) + pow(p1.y - p2.y, 2));
}

double total_cost(const Point &i, const Point &j, const Point &k) {
    return dist(i, j) + dist(j, k) + dist(k, i);
}

bool intersect(const Point &p1, const Point &p2, const Point &p3, const Point &p4) {
    // Compute the cross products of vectors (p1, p2) x (p1, p3) and (p1, p2) x (p1, p4)
    int cp1 = (p2.x - p1.x) * (p3.y - p1.y) - (p2.y - p1.y) * (p3.x - p1.x);
    int cp2 = (p2.x - p1.x) * (p4.y - p1.y) - (p2.y - p1.y) * (p4.x - p1.x);

    // Compute the cross products of vectors (p3, p4) x (p3, p1) and (p3, p4) x (p3, p2)
    int cp3 = (p4.x - p3.x) * (p1.y - p3.y) - (p4.y - p3.y) * (p1.x - p3.x);
    int cp4 = (p4.x - p3.x) * (p2.y - p3.y) - (p4.y - p3.y) * (p2.x - p3.x);

    // If the cross products have opposite signs, the line segments intersect
    return (cp1 * cp2 < 0) && (cp3 * cp4 < 0);
}

bool is_valid_diagonal(const vector<Point> &points, int i, int j) {
    // Check if the diagonal connects non-adjacent vertices
    int n = points.size();
    if (abs(i - j) == 1 || abs(i - j) == n - 1) {
        return false;
    }

    // Check if the diagonal intersects with any previously selected diagonal
    for (int k = 0; k < n; ++k) {
        if (k != i && k != j && (k + 1) % n != i && (k + 1) % n != j) {
            if (intersect(points[i], points[j], points[k], points[(k + 1) % n])) {
                return false;
            }
        }
    }

    return true;
}

double greedy_min_cost_triangulation(const vector<Point> &points) {
    int n = points.size();

    // Check for triangle case
    if (n == 3) {
        return dist(points[0], points[1]) + dist(points[1], points[2]) + dist(points[2], points[0]);
    }
    double min_cost = numeric_limits<double>::max();

    vector<pair<double, pair<int, int>>> diagonals;
    for (int i = 0; i < n; ++i) {
        for (int j = i + 2; j < n; ++j) {
            if (is_valid_diagonal(points, i, j)) {
                double cost = dist(points[i], points[j]);
                diagonals.push_back({cost, {i, j}});
            }
        }
    }

    sort(diagonals.begin(), diagonals.end());
    vector<bool> used_diagonals(n, false);
    double total_min_cost = 0;

    for (const auto &diag : diagonals) {
        int i = diag.second.first;
        int j = diag.second.second;

        if (!used_diagonals[i] && !used_diagonals[j]) {
            used_diagonals[i] = true;
            used_diagonals[j] = true;
            total_min_cost += total_cost(points[i], points[(i + 1) % n], points[j]);
        }
    }

    return total_min_cost;
}

int main() {
    ifstream infile("output.txt");
    ofstream outfile("greedy.txt");

    int N;
    while (infile >> N)
    {
         vector<Point> points(N);
        for (int i = 0; i < N; i++)
        {
            infile >> points[i].x >> points[i].y;
        }

        double result = greedy_min_cost_triangulation(points);

        outfile << "Number of vertices: " << N << endl;
        outfile << result << endl;
    }
    infile.close();
    outfile.close();
    return 0;
}