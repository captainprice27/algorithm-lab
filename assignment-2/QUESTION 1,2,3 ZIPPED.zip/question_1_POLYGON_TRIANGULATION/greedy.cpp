#include <bits/stdc++.h>

using namespace std;

struct Point
{
    double x, y;
};

struct Edge
{
    int i, j;
    double length;
};

bool compareEdges(Edge e1, Edge e2)
{
    return e1.length < e2.length;
}

double dist(Point p1, Point p2)
{
    return sqrt(pow(p1.x - p2.x, 2) + pow(p1.y - p2.y, 2));
}

bool segmentsIntersect(Point p1, Point p2, Point q1, Point q2)
{
    double cross1 = (q2.y - q1.y) * (p1.x - q1.x) - (q2.x - q1.x) * (p1.y - q1.y);
    double cross2 = (q2.y - q1.y) * (p2.x - q1.x) - (q2.x - q1.x) * (p2.y - q1.y);
    double cross3 = (p2.y - p1.y) * (q1.x - p1.x) - (p2.x - p1.x) * (q1.y - p1.y);
    double cross4 = (p2.y - p1.y) * (q2.x - p1.x) - (p2.x - p1.x) * (q2.y - p1.y);

    return (cross1 * cross2 < 0) && (cross3 * cross4 < 0);
}

int main()
{
    ifstream infile("output.txt");
    int N;
    while (infile >> N)
    {

        if (N == 0)
            break;

        vector<Point> points(N);
        for (int i = 0; i < N; i++)
        {
            infile >> points[i].x >> points[i].y;
        }

        vector<double> edge_lengths;
        for (int i = 0; i < N; i++)
        {
            for (int j = i + 1; j < N; j++)
            {
                double d = dist(points[i], points[j]);
                edge_lengths.push_back(d);
            }
        }

        // sort the edge lengths in ascending order
        sort(edge_lengths.begin(), edge_lengths.end());

        // print out the sorted edge lengths for this polygon
        for (int i = 0; i < edge_lengths.size(); i++)
        {
            cout << edge_lengths[i] << " ";
        }
        cout << endl;
    }

    infile.close();
    return 0;
}
