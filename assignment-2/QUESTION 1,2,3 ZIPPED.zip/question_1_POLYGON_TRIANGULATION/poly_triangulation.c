#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

// constants
#define MAX_VAL 200

int cmp(const void *a, const void *b)
{
    float c = (*(float *)a - *(float *)b);
    return (int)(c * 100);
}

typedef struct
{
    int x, y;
} Point;

typedef struct
{
    Point *arr;
    int nops;
} Polygon;

Point generate_point()
{
    Point p;
    p.x = rand() % MAX_VAL;
    p.y = rand() % MAX_VAL;
    return p;
}

float min(float a, float b)
{
    return (a < b) ? a : b;
}

float max(float a, float b)
{
    return (a > b) ? a : b;
}

float dist(Point p1, Point p2)
{
    return sqrt(pow((p1.x - p2.x), 2) + (pow((p1.y - p2.y), 2)));
}

int crossProduct(Point p1, Point p2, Point p3)
{
    int x1 = p2.x - p1.x;
    int y1 = p2.y - p1.y;
    int x2 = p3.x - p2.x;
    int y2 = p3.y - p2.y;
    return (x1 * y2 - y1 * x2);
}

int isConvex(Point arr[], int n)
{
    int prev, curr = 0;
    for (int i = 0; i < n; i++)
    {
        curr = crossProduct(arr[i], arr[(i + 1) % n], arr[(i + 2) % n]);
        if (curr != 0)
        {
            if (curr * prev < 0)
                return 0;
            else
                prev = curr;
        }
    }
    return 1;
}

Polygon createPoly(int n)
{
    Polygon p;
    p.nops = n;
    p.arr = (Point *)malloc(n * sizeof(Point));
    p.arr[0] = generate_point();
    Point temp[n];
    temp[0] = p.arr[0];
    for (int i = 1; i < n; i++)
    {
        Point pnt;
        do
        {
            pnt = generate_point();
            temp[i] = pnt;
        } while (!isConvex(temp, i + 1));
        p.arr[i] = pnt;
    }
    return p;
}

void display(Polygon p, int n)
{
    for (int i = 0; i < n; i++)
    {
        printf("(%d, %d), ", p.arr[i].x, p.arr[i].y);
    }
    printf("\n");
}

float cost(Point p[], int i, int j, int k)
{
    Point p1 = p[i];
    Point p2 = p[j];
    Point p3 = p[k];
    return dist(p1, p2) + dist(p2, p3) + dist(p3, p1);
}

float min_Triangulation_Cost(Polygon p, int i, int j)
{
    if (j <= i + 1)
    {
        return 0;
    }
    float ans = 1e7;
    for (int k = i + 1; k < j; k++)
    {
        ans = min(ans, (min_Triangulation_Cost(p, i, k) + min_Triangulation_Cost(p, k, j) + cost(p.arr, i, k, j)));
    }
    return ans;
}

float min_Triangulation_Cost_DP(Polygon p)
{
    int n = p.nops;
    if (n < 3)
        return 0;
    float table[n][n];
    for (int gap = 0; gap < n; gap++)
    {
        for (int i = 0, j = gap; j < n; i++, j++)
        {
            if (j < i + 2)
                table[i][j] = 0.0;
            else
            {
                table[i][j] = 1e7;
                for (int k = i + 1; k < j; k++)
                {
                    float val = table[i][k] + table[k][j] + cost(p.arr, i, j, k);
                    if (table[i][j] > val)
                        table[i][j] = val;
                }
            }
        }
    }
    return table[0][n - 1];
}

float perimeter(Polygon p)
{
    int n = p.nops;
    float d = dist(p.arr[0], p.arr[n - 1]);
    for (int i = 0; i < n - 1; i++)
        d += dist(p.arr[i], p.arr[i + 1]);
    return d;
}

int search(float **arr, float d, int i, int j, int l, int k)
{
    if (arr[i][j] == d)
    {
        if ((i == l && j == k) || (i == k && j == l))
        {
            return 0;
        }
        else if ((i == l || j == k) || (i == k || j == l))
            return 1;
        else if ((i < min(k, l)) && (j < min(k, l)))
            return 1;
        else if ((i > max(k, l)) && (j > max(k, l)))
            return 1;
        else if ((i > min(k, l) && i < max(k, l)) && (j > min(k, l) && j < max(k, l)))
            return 1;
        else if ((i < min(k, l) && j > max(k, l)) || (i > max(k, l) && j < min(k, l)))
            return 1;
        else
        {
            return 0;
        }
    }
    return 0;
}

int com_search(float **arr, float d, int i, int j, int n, int **crr)
{
    if (n == 0)
    {
        if (arr[i][j] == d)
        {
            return 1;
        }
        return 0;
    }
    int c;
    for (int l = 0; l < n; l++)
    {
        c = search(arr, d, i, j, crr[l][0], crr[l][1]);
        if (c == 0)
        {
            return 0;
        }
    }
    return 1;
}

int hello()
{
    return 0;
}

float min_Triangulation_Cost_Greedy(Polygon p)
{
    int n = p.nops;
    float **diag = (float **)malloc(n * sizeof(float *));
    float *brr = (float *)malloc((n * (n - 3) / 2) * sizeof(float));
    int l = 0;
    for (int i = 0; i < n; i++)
    {
        diag[i] = (float *)malloc(n * sizeof(float));
    }

    for (int i = 0; i < n; i++)
    {
        int t = hello();
        for (int j = 0; j < n; j++)
        {
            if (j < i + 2)
                diag[i][j] = 0;
            else
            {
                if (l == 0 && j == n - 1)
                    diag[i][j] = 0;
                else
                {
                    diag[i][j] = dist(p.arr[i], p.arr[j]);
                    brr[l++] = diag[i][j];
                }
            }
        }
    }
    qsort(brr, l, sizeof(float), cmp);

    int **crr = (int **)malloc((n - 3) * sizeof(int *));
    int z = 0, y;
    float d = perimeter(p);

    for (int i = 0; i < n - 3; i++)
    {
        crr[i] = (int *)malloc(2 * sizeof(int));
        y = 0;
        while (y != 1)
        {
            for (int m = 0; m < n; m++)
            {
                for (int k = m + 2; k < n; k++)
                {
                    if (com_search(diag, brr[z], m, k, i, crr))
                    {
                        crr[i][0] = m;
                        crr[i][1] = k;
                        y = 1;
                        d += 2 * dist(p.arr[m], p.arr[k]);
                        break;
                    }
                }
                if (y == 1)
                {
                    break;
                }
            }
            if (z >= l)
            {
                break;
            }
            else
                z++;
        }
    }

    return d;
}

int main()
{
    srand(time(0));
    float time = 0, timeDP = 0, timeGreedy = 0;
    FILE *fp = fopen("Result.csv", "w");
    fprintf(fp, "nop,time,timeDP,timeGreedy\n");
    int limit;
    printf("how many polygons: ");
    scanf("%d", &limit);
    for (int i = 3; i <= limit; i++)
    {
        double start_time, end_time;
        Polygon p = createPoly(i);
        start_time = clock();
        printf("%d:  %lf\n", i, min_Triangulation_Cost(p, 0, i - 1));
        end_time = clock();
        time = (end_time - start_time) * 1000 / CLOCKS_PER_SEC;

        start_time = clock();
        printf("%d:  %lf\n", i, min_Triangulation_Cost_DP(p));
        end_time = clock();
        timeDP = (end_time - start_time) * 1000 / CLOCKS_PER_SEC;

        start_time = clock();
        float res = min_Triangulation_Cost_Greedy(p);
        printf("%d: %lf\n", i, res);
        end_time = clock();
        timeGreedy = (end_time - start_time) * 1000 / CLOCKS_PER_SEC;

        free(p.arr);

        fprintf(fp, "%d,%.4f,%.4f,%.4f\n", i, time, timeDP, timeGreedy);
    }
}
